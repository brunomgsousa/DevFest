#include <ESP8266WiFi.h>
#include "DHT.h"
#include <WebSocketsServer.h>
const char* ssid = "MovimentoMaker";
const char* password = "123456789";

WebSocketsServer sock = WebSocketsServer(80);

WiFiClient wifiClient;
void webSocketEvent(uint8_t num, WStype_t type, uint8_t *payload, size_t length);

#define DHTPIN 4    //Fisicamente é o pino 2 da board // what digital pin we're connected to

#define DHTTYPE DHT11   // DHT 22  (AM2302), AM2321

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  delay(10);
  dht.begin();
  sock.begin();
  sock.onEvent(webSocketEvent);

}

void loop() {
  if(WiFi.status() != WL_CONNECTED) { 
      Serial.println();
      Serial.println();
      Serial.print("Connecting to ");
      Serial.println(ssid);  
      WiFi.begin(ssid, password);

  
    while(WiFi.status() != WL_CONNECTED)
    {
    delay(500);
    Serial.print(".");    
    }
      Serial.println("");
      Serial.println("WiFi connected");  
      Serial.println("IP address: ");
      Serial.println(WiFi.localIP());
  }
  else
  {
      sock.loop();
  }
}


void webSocketEvent(uint8_t num, WStype_t type, uint8_t *payload, size_t length)
{
  //Todos os eventos vão cair aqui
  IPAddress ip = sock.remoteIP(num);
   
  switch(type)
  {
      case WStype_DISCONNECTED:
          Serial.println("Disconnected!");
          break;
      case WStype_CONNECTED:
          Serial.printf("New Client: %d.%d.%d.%d\n", ip[0], ip[1], ip[2], ip[3]);
          break;
      case WStype_TEXT:
      {
          String s = (char*)payload;
          Serial.println("Aqui passam as mensagens a ser filtradas no servidor [" + s + "]");

          // Reading temperature or humidity takes about 250 milliseconds!
          // Sensor readings may also be up to 2 seconds 'old' (its a very slow sensor)
          float h = dht.readHumidity();
          // Read temperature as Celsius (the default)
          float t = dht.readTemperature();
          // Read temperature as Fahrenheit (isFahrenheit = true)
          float f = dht.readTemperature(true);

          // Check if any reads failed and exit early (to try again).
          if (isnan(h) || isnan(t) || isnan(f)) {
            Serial.println(F("Failed to read from DHT sensor!"));
            return;
          }

          // Compute heat index in Celsius (isFahreheit = false)
          float hic = dht.computeHeatIndex(t, h, false);

          /*Serial.print(F("Humidity: "));
          Serial.print(h);
          Serial.print(F("%  Temperature: "));
          Serial.print(t);
          Serial.print(F("°C "));
          Serial.print(f);
          Serial.print(F("°F  Heat index: "));
          Serial.print(hic);
          Serial.print(F("°C "));
          Serial.print(hif);
          Serial.println(F("°F"));
        */
          //Vamos enviar via socket a temperatura e humidade para o nosso cliente do websocket que fez o pedido.
          if(s == "Temperatura")
          {
              sock.sendTXT(num, "Temperatura: "+ String(hic) + "ºC");             
          }
          else
          if(s == "Humidade")          
          {
              sock.sendTXT(num, "Humidade: " + String(h) + "%");
          }
          else
          {
              sock.sendTXT(num, "Temperatura: "+ String(hic) + "ºC, Humidade: " + String(h) + "%");
          }
                                           
         break;
      }
      default:
          break;
  }
}